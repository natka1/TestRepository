package Pages;

/**
 * Created by DELL on 4/2/2017.
 */
public class BasePage {

}
