package Tests;

import org.junit.AfterClass;
import org.junit.rules.Timeout;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created by DELL on 3/26/2017.
 */
public class MyTest {
    WebDriver driver;

    @DataProvider(name = "Name1")
    public static Object[][] Name1() {
    return new Object[][]{{"https://mail.ru/"},
                          {"https://mail.ru/"}};
    }

    @DataProvider(name = "myDateProvider")
    public static Object[][] myDateProvider() {
        return  new Object[][]{{"http://korrespondent.net/"},
                               {"https://mail.ru/"}};

    }

    @BeforeClass
    public void setUp() throws Exception {
        System.setProperty("webdriver.gecko.driver","drivers\\geckodriver.exe");
     //   driver= new FirefoxDriver();

    }

    @Test(description = "Test Test Test",dataProvider = "Name1")
    public void testTest(String url) throws Exception {
        driver.get(url);
       Assert.assertFalse(false);
    }

    @Test(invocationTimeOut = 1000)
    public void testTest1() throws Exception {
     //   Thread.sleep(2000);
        Assert.assertFalse(false);

    }

    @Test(dependsOnMethods ={"testTest","testTest1"})
    public void testTest2() throws Exception {
        Assert.assertFalse(false);
    }

    @AfterClass
    public void afterUp() throws Exception {
    //  driver.quit();

    }

}
