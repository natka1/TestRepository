package Pages;

import com.gargoylesoftware.htmlunit.WebAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by DELL on 4/2/2017.
 */
public class LoginPage {
    WebDriver driver;

	@FindBy(id="mailbox__login")
	@Android

	private WebElement name_;

	@FindBy(id="mailbox__password")
	private WebElement password_;

	@FindBy(id="mailbox__auth__button")
	private WebElement authButton;


	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	AfterLoginPage login(String name, String password){
		name_.sendKeys(name);
		password_.sendKeys(password);
		authButton.submit();
		return new AfterLoginPage(driver);
	}

}
